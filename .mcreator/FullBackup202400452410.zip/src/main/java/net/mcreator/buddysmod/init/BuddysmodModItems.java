
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.buddysmod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.buddysmod.item.LuckyCoreItem;
import net.mcreator.buddysmod.BuddysmodMod;

public class BuddysmodModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(BuddysmodMod.MODID);
	public static final DeferredItem<Item> LUCKY_BLOCK = block(BuddysmodModBlocks.LUCKY_BLOCK);
	public static final DeferredItem<Item> LUCKY_CORE = REGISTRY.register("lucky_core", LuckyCoreItem::new);
	public static final DeferredItem<Item> LUCKY_ORE = block(BuddysmodModBlocks.LUCKY_ORE);
	public static final DeferredItem<Item> REINFORCED_GLASS = block(BuddysmodModBlocks.REINFORCED_GLASS);
	public static final DeferredItem<Item> RARE_LUCKY_BLOCK = block(BuddysmodModBlocks.RARE_LUCKY_BLOCK);
	public static final DeferredItem<Item> FARMER_LUCKY_BLOCK = block(BuddysmodModBlocks.FARMER_LUCKY_BLOCK);
	public static final DeferredItem<Item> REDSTONE_LUCKY_BLOCK = block(BuddysmodModBlocks.REDSTONE_LUCKY_BLOCK);

	// Start of user code block custom items
	// End of user code block custom items
	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
