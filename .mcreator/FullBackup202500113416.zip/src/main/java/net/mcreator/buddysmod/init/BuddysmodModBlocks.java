
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.buddysmod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.Block;

import net.mcreator.buddysmod.block.ReinforcedGlassBlock;
import net.mcreator.buddysmod.block.RedstoneLuckyBlockBlock;
import net.mcreator.buddysmod.block.RareLuckyBlockBlock;
import net.mcreator.buddysmod.block.LuckyOreBlock;
import net.mcreator.buddysmod.block.LuckyBlockBlock;
import net.mcreator.buddysmod.block.FarmerLuckyBlockBlock;
import net.mcreator.buddysmod.BuddysmodMod;

public class BuddysmodModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(BuddysmodMod.MODID);
	public static final DeferredBlock<Block> LUCKY_BLOCK = REGISTRY.register("lucky_block", LuckyBlockBlock::new);
	public static final DeferredBlock<Block> LUCKY_ORE = REGISTRY.register("lucky_ore", LuckyOreBlock::new);
	public static final DeferredBlock<Block> REINFORCED_GLASS = REGISTRY.register("reinforced_glass", ReinforcedGlassBlock::new);
	public static final DeferredBlock<Block> RARE_LUCKY_BLOCK = REGISTRY.register("rare_lucky_block", RareLuckyBlockBlock::new);
	public static final DeferredBlock<Block> FARMER_LUCKY_BLOCK = REGISTRY.register("farmer_lucky_block", FarmerLuckyBlockBlock::new);
	public static final DeferredBlock<Block> REDSTONE_LUCKY_BLOCK = REGISTRY.register("redstone_lucky_block", RedstoneLuckyBlockBlock::new);
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
