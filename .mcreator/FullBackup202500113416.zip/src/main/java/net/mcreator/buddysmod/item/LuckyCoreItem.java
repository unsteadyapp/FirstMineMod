
package net.mcreator.buddysmod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class LuckyCoreItem extends Item {
	public LuckyCoreItem() {
		super(new Item.Properties().stacksTo(64).fireResistant().rarity(Rarity.COMMON));
	}
}
